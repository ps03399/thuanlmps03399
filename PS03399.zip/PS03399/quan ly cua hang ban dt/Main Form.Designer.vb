﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ĐăngXuấtToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuảnLýDanhMụcToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ĐặcĐiểmMặtHàngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ThôngTinNhàSảnXuấtToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuảnLýMặtHàngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ThêmMớiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CậpNhậtToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuảnLýKháchHàngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ThêmMớiToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CậpNhậtToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuảnLýBánHàngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ĐơnHàngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ThêmMớiToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ThanhToánToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ThốngKêToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MặtHàngBánChạyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TìnhTrạngTồnKhoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TìmKiếmToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TidmKiếmKháchHàngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TìmKiếmMặtHàngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.QuảnLýDanhMụcToolStripMenuItem, Me.QuảnLýMặtHàngToolStripMenuItem, Me.QuảnLýKháchHàngToolStripMenuItem, Me.QuảnLýBánHàngToolStripMenuItem, Me.ThốngKêToolStripMenuItem, Me.TìmKiếmToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(812, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ĐăngXuấtToolStripMenuItem})
        Me.FileToolStripMenuItem.Image = CType(resources.GetObject("FileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'ĐăngXuấtToolStripMenuItem
        '
        Me.ĐăngXuấtToolStripMenuItem.Image = CType(resources.GetObject("ĐăngXuấtToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ĐăngXuấtToolStripMenuItem.Name = "ĐăngXuấtToolStripMenuItem"
        Me.ĐăngXuấtToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.ĐăngXuấtToolStripMenuItem.Text = "&Đăng Xuất"
        '
        'QuảnLýDanhMụcToolStripMenuItem
        '
        Me.QuảnLýDanhMụcToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ĐặcĐiểmMặtHàngToolStripMenuItem, Me.ThôngTinNhàSảnXuấtToolStripMenuItem})
        Me.QuảnLýDanhMụcToolStripMenuItem.Image = CType(resources.GetObject("QuảnLýDanhMụcToolStripMenuItem.Image"), System.Drawing.Image)
        Me.QuảnLýDanhMụcToolStripMenuItem.Name = "QuảnLýDanhMụcToolStripMenuItem"
        Me.QuảnLýDanhMụcToolStripMenuItem.Size = New System.Drawing.Size(137, 20)
        Me.QuảnLýDanhMụcToolStripMenuItem.Text = "Quản Lý Danh Mục"
        '
        'ĐặcĐiểmMặtHàngToolStripMenuItem
        '
        Me.ĐặcĐiểmMặtHàngToolStripMenuItem.Image = CType(resources.GetObject("ĐặcĐiểmMặtHàngToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ĐặcĐiểmMặtHàngToolStripMenuItem.Name = "ĐặcĐiểmMặtHàngToolStripMenuItem"
        Me.ĐặcĐiểmMặtHàngToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.ĐặcĐiểmMặtHàngToolStripMenuItem.Text = "Đặc Điểm Mặt Hàng"
        '
        'ThôngTinNhàSảnXuấtToolStripMenuItem
        '
        Me.ThôngTinNhàSảnXuấtToolStripMenuItem.Image = CType(resources.GetObject("ThôngTinNhàSảnXuấtToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ThôngTinNhàSảnXuấtToolStripMenuItem.Name = "ThôngTinNhàSảnXuấtToolStripMenuItem"
        Me.ThôngTinNhàSảnXuấtToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.ThôngTinNhàSảnXuấtToolStripMenuItem.Text = "Thông Tin Nhà Sản Xuất"
        '
        'QuảnLýMặtHàngToolStripMenuItem
        '
        Me.QuảnLýMặtHàngToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ThêmMớiToolStripMenuItem, Me.CậpNhậtToolStripMenuItem})
        Me.QuảnLýMặtHàngToolStripMenuItem.Image = CType(resources.GetObject("QuảnLýMặtHàngToolStripMenuItem.Image"), System.Drawing.Image)
        Me.QuảnLýMặtHàngToolStripMenuItem.Name = "QuảnLýMặtHàngToolStripMenuItem"
        Me.QuảnLýMặtHàngToolStripMenuItem.Size = New System.Drawing.Size(135, 20)
        Me.QuảnLýMặtHàngToolStripMenuItem.Text = "Quản Lý Mặt Hàng"
        '
        'ThêmMớiToolStripMenuItem
        '
        Me.ThêmMớiToolStripMenuItem.Image = CType(resources.GetObject("ThêmMớiToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ThêmMớiToolStripMenuItem.Name = "ThêmMớiToolStripMenuItem"
        Me.ThêmMớiToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.ThêmMớiToolStripMenuItem.Text = "Thêm Mới"
        '
        'CậpNhậtToolStripMenuItem
        '
        Me.CậpNhậtToolStripMenuItem.Image = CType(resources.GetObject("CậpNhậtToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CậpNhậtToolStripMenuItem.Name = "CậpNhậtToolStripMenuItem"
        Me.CậpNhậtToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.CậpNhậtToolStripMenuItem.Text = "Cập Nhật"
        '
        'QuảnLýKháchHàngToolStripMenuItem
        '
        Me.QuảnLýKháchHàngToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ThêmMớiToolStripMenuItem1, Me.CậpNhậtToolStripMenuItem1})
        Me.QuảnLýKháchHàngToolStripMenuItem.Image = CType(resources.GetObject("QuảnLýKháchHàngToolStripMenuItem.Image"), System.Drawing.Image)
        Me.QuảnLýKháchHàngToolStripMenuItem.Name = "QuảnLýKháchHàngToolStripMenuItem"
        Me.QuảnLýKháchHàngToolStripMenuItem.Size = New System.Drawing.Size(147, 20)
        Me.QuảnLýKháchHàngToolStripMenuItem.Text = "Quản Lý Khách Hàng"
        '
        'ThêmMớiToolStripMenuItem1
        '
        Me.ThêmMớiToolStripMenuItem1.Image = CType(resources.GetObject("ThêmMớiToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ThêmMớiToolStripMenuItem1.Name = "ThêmMớiToolStripMenuItem1"
        Me.ThêmMớiToolStripMenuItem1.Size = New System.Drawing.Size(129, 22)
        Me.ThêmMớiToolStripMenuItem1.Text = "Thêm Mới"
        '
        'CậpNhậtToolStripMenuItem1
        '
        Me.CậpNhậtToolStripMenuItem1.Image = CType(resources.GetObject("CậpNhậtToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.CậpNhậtToolStripMenuItem1.Name = "CậpNhậtToolStripMenuItem1"
        Me.CậpNhậtToolStripMenuItem1.Size = New System.Drawing.Size(129, 22)
        Me.CậpNhậtToolStripMenuItem1.Text = "Cập Nhật"
        '
        'QuảnLýBánHàngToolStripMenuItem
        '
        Me.QuảnLýBánHàngToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ĐơnHàngToolStripMenuItem, Me.ThanhToánToolStripMenuItem})
        Me.QuảnLýBánHàngToolStripMenuItem.Image = CType(resources.GetObject("QuảnLýBánHàngToolStripMenuItem.Image"), System.Drawing.Image)
        Me.QuảnLýBánHàngToolStripMenuItem.Name = "QuảnLýBánHàngToolStripMenuItem"
        Me.QuảnLýBánHàngToolStripMenuItem.Size = New System.Drawing.Size(134, 20)
        Me.QuảnLýBánHàngToolStripMenuItem.Text = "Quản Lý Bán Hàng"
        '
        'ĐơnHàngToolStripMenuItem
        '
        Me.ĐơnHàngToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ThêmMớiToolStripMenuItem2})
        Me.ĐơnHàngToolStripMenuItem.Image = CType(resources.GetObject("ĐơnHàngToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ĐơnHàngToolStripMenuItem.Name = "ĐơnHàngToolStripMenuItem"
        Me.ĐơnHàngToolStripMenuItem.Size = New System.Drawing.Size(138, 22)
        Me.ĐơnHàngToolStripMenuItem.Text = "Đơn Hàng"
        '
        'ThêmMớiToolStripMenuItem2
        '
        Me.ThêmMớiToolStripMenuItem2.Image = CType(resources.GetObject("ThêmMớiToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.ThêmMớiToolStripMenuItem2.Name = "ThêmMớiToolStripMenuItem2"
        Me.ThêmMớiToolStripMenuItem2.Size = New System.Drawing.Size(197, 22)
        Me.ThêmMớiToolStripMenuItem2.Text = "Thêm Mới và Cập Nhật"
        '
        'ThanhToánToolStripMenuItem
        '
        Me.ThanhToánToolStripMenuItem.Image = CType(resources.GetObject("ThanhToánToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ThanhToánToolStripMenuItem.Name = "ThanhToánToolStripMenuItem"
        Me.ThanhToánToolStripMenuItem.Size = New System.Drawing.Size(138, 22)
        Me.ThanhToánToolStripMenuItem.Text = "Thanh Toán"
        '
        'ThốngKêToolStripMenuItem
        '
        Me.ThốngKêToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MặtHàngBánChạyToolStripMenuItem, Me.TìnhTrạngTồnKhoToolStripMenuItem})
        Me.ThốngKêToolStripMenuItem.Image = CType(resources.GetObject("ThốngKêToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ThốngKêToolStripMenuItem.Name = "ThốngKêToolStripMenuItem"
        Me.ThốngKêToolStripMenuItem.Size = New System.Drawing.Size(89, 20)
        Me.ThốngKêToolStripMenuItem.Text = "Thống Kê "
        '
        'MặtHàngBánChạyToolStripMenuItem
        '
        Me.MặtHàngBánChạyToolStripMenuItem.Image = CType(resources.GetObject("MặtHàngBánChạyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MặtHàngBánChạyToolStripMenuItem.Name = "MặtHàngBánChạyToolStripMenuItem"
        Me.MặtHàngBánChạyToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.MặtHàngBánChạyToolStripMenuItem.Text = "Mặt Hàng Bán Chạy"
        '
        'TìnhTrạngTồnKhoToolStripMenuItem
        '
        Me.TìnhTrạngTồnKhoToolStripMenuItem.Image = CType(resources.GetObject("TìnhTrạngTồnKhoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TìnhTrạngTồnKhoToolStripMenuItem.Name = "TìnhTrạngTồnKhoToolStripMenuItem"
        Me.TìnhTrạngTồnKhoToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TìnhTrạngTồnKhoToolStripMenuItem.Text = "Tình Trạng Tồn Kho"
        '
        'TìmKiếmToolStripMenuItem
        '
        Me.TìmKiếmToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TidmKiếmKháchHàngToolStripMenuItem, Me.TìmKiếmMặtHàngToolStripMenuItem})
        Me.TìmKiếmToolStripMenuItem.Image = CType(resources.GetObject("TìmKiếmToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TìmKiếmToolStripMenuItem.Name = "TìmKiếmToolStripMenuItem"
        Me.TìmKiếmToolStripMenuItem.Size = New System.Drawing.Size(86, 20)
        Me.TìmKiếmToolStripMenuItem.Text = "Tìm Kiếm"
        '
        'TidmKiếmKháchHàngToolStripMenuItem
        '
        Me.TidmKiếmKháchHàngToolStripMenuItem.Image = CType(resources.GetObject("TidmKiếmKháchHàngToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TidmKiếmKháchHàngToolStripMenuItem.Name = "TidmKiếmKháchHàngToolStripMenuItem"
        Me.TidmKiếmKháchHàngToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.TidmKiếmKháchHàngToolStripMenuItem.Text = "Tìm Kiếm Khách Hàng"
        '
        'TìmKiếmMặtHàngToolStripMenuItem
        '
        Me.TìmKiếmMặtHàngToolStripMenuItem.Image = CType(resources.GetObject("TìmKiếmMặtHàngToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TìmKiếmMặtHàngToolStripMenuItem.Name = "TìmKiếmMặtHàngToolStripMenuItem"
        Me.TìmKiếmMặtHàngToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.TìmKiếmMặtHàngToolStripMenuItem.Text = "Tìm Kiếm Mặt Hàng"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 27)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(812, 383)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(569, 386)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(243, 24)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Lê Minh Thuận_PS03399"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(812, 411)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Main Menu"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ĐăngXuấtToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuảnLýDanhMụcToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ĐặcĐiểmMặtHàngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ThôngTinNhàSảnXuấtToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuảnLýMặtHàngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ThêmMớiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CậpNhậtToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuảnLýKháchHàngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ThêmMớiToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CậpNhậtToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuảnLýBánHàngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ĐơnHàngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ThêmMớiToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ThanhToánToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ThốngKêToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MặtHàngBánChạyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TìnhTrạngTồnKhoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TìmKiếmToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TidmKiếmKháchHàngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TìmKiếmMặtHàngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
