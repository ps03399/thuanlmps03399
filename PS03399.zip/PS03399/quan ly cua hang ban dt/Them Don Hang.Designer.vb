﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Them_Don_Hang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Them_Don_Hang))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TextBoxMaKH = New System.Windows.Forms.TextBox()
        Me.TextBoxMaLoaiDH = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.TextBoxNguoiLap = New System.Windows.Forms.TextBox()
        Me.ComboBoxMaNSX = New System.Windows.Forms.ComboBox()
        Me.TextBoxMaDH = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ButtonXoa = New System.Windows.Forms.Button()
        Me.ButtonCapNhat = New System.Windows.Forms.Button()
        Me.TextBoxMaMH = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBoxGia = New System.Windows.Forms.TextBox()
        Me.TextBoxSoLuong = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TextBoxMaKH)
        Me.GroupBox1.Controls.Add(Me.TextBoxMaLoaiDH)
        Me.GroupBox1.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox1.Controls.Add(Me.TextBoxNguoiLap)
        Me.GroupBox1.Controls.Add(Me.ComboBoxMaNSX)
        Me.GroupBox1.Controls.Add(Me.TextBoxMaDH)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(599, 130)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Thông Tin Chung Của Đơn Hàng"
        '
        'TextBoxMaKH
        '
        Me.TextBoxMaKH.Location = New System.Drawing.Point(402, 62)
        Me.TextBoxMaKH.Name = "TextBoxMaKH"
        Me.TextBoxMaKH.Size = New System.Drawing.Size(172, 20)
        Me.TextBoxMaKH.TabIndex = 15
        '
        'TextBoxMaLoaiDH
        '
        Me.TextBoxMaLoaiDH.Location = New System.Drawing.Point(402, 31)
        Me.TextBoxMaLoaiDH.Name = "TextBoxMaLoaiDH"
        Me.TextBoxMaLoaiDH.Size = New System.Drawing.Size(172, 20)
        Me.TextBoxMaLoaiDH.TabIndex = 14
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(402, 94)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(172, 20)
        Me.DateTimePicker1.TabIndex = 13
        '
        'TextBoxNguoiLap
        '
        Me.TextBoxNguoiLap.Location = New System.Drawing.Point(86, 97)
        Me.TextBoxNguoiLap.Name = "TextBoxNguoiLap"
        Me.TextBoxNguoiLap.Size = New System.Drawing.Size(174, 20)
        Me.TextBoxNguoiLap.TabIndex = 12
        '
        'ComboBoxMaNSX
        '
        Me.ComboBoxMaNSX.FormattingEnabled = True
        Me.ComboBoxMaNSX.Location = New System.Drawing.Point(86, 62)
        Me.ComboBoxMaNSX.Name = "ComboBoxMaNSX"
        Me.ComboBoxMaNSX.Size = New System.Drawing.Size(174, 21)
        Me.ComboBoxMaNSX.TabIndex = 10
        '
        'TextBoxMaDH
        '
        Me.TextBoxMaDH.Location = New System.Drawing.Point(86, 31)
        Me.TextBoxMaDH.Name = "TextBoxMaDH"
        Me.TextBoxMaDH.Size = New System.Drawing.Size(174, 20)
        Me.TextBoxMaDH.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(299, 100)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Ngày Lập"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 100)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Người Lập"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(299, 65)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Mã Khách Hàng"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Mã NSX"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(299, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Mã Loại Đơn Hàng"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Mã Đơn Hàng"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.ButtonXoa)
        Me.GroupBox2.Controls.Add(Me.ButtonCapNhat)
        Me.GroupBox2.Controls.Add(Me.TextBoxMaMH)
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.TextBoxGia)
        Me.GroupBox2.Controls.Add(Me.TextBoxSoLuong)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 148)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(599, 91)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Chi Tiết Đơn Hàng"
        '
        'ButtonXoa
        '
        Me.ButtonXoa.Location = New System.Drawing.Point(302, 62)
        Me.ButtonXoa.Name = "ButtonXoa"
        Me.ButtonXoa.Size = New System.Drawing.Size(75, 23)
        Me.ButtonXoa.TabIndex = 10
        Me.ButtonXoa.Text = "Xoá"
        Me.ButtonXoa.UseVisualStyleBackColor = True
        '
        'ButtonCapNhat
        '
        Me.ButtonCapNhat.Location = New System.Drawing.Point(165, 62)
        Me.ButtonCapNhat.Name = "ButtonCapNhat"
        Me.ButtonCapNhat.Size = New System.Drawing.Size(75, 23)
        Me.ButtonCapNhat.TabIndex = 9
        Me.ButtonCapNhat.Text = "Cập Nhật"
        Me.ButtonCapNhat.UseVisualStyleBackColor = True
        '
        'TextBoxMaMH
        '
        Me.TextBoxMaMH.Location = New System.Drawing.Point(81, 28)
        Me.TextBoxMaMH.Name = "TextBoxMaMH"
        Me.TextBoxMaMH.Size = New System.Drawing.Size(64, 20)
        Me.TextBoxMaMH.TabIndex = 8
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(427, 62)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Thoát"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(56, 62)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Thêm Mới"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBoxGia
        '
        Me.TextBoxGia.Location = New System.Drawing.Point(345, 28)
        Me.TextBoxGia.Name = "TextBoxGia"
        Me.TextBoxGia.Size = New System.Drawing.Size(126, 20)
        Me.TextBoxGia.TabIndex = 5
        '
        'TextBoxSoLuong
        '
        Me.TextBoxSoLuong.Location = New System.Drawing.Point(234, 28)
        Me.TextBoxSoLuong.Name = "TextBoxSoLuong"
        Me.TextBoxSoLuong.Size = New System.Drawing.Size(54, 20)
        Me.TextBoxSoLuong.TabIndex = 4
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(316, 31)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(23, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Giá"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(175, 31)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Số Lượng"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 31)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Mã Mặt Hàng"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.DataGridView1)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 245)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(591, 157)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Danh Sách Đơn Hàng"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(6, 19)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(585, 132)
        Me.DataGridView1.TabIndex = 0
        '
        'Them_Don_Hang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(615, 420)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Them_Don_Hang"
        Me.Text = "Thêm Và Cập Nhật Đơn Hàng"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBoxNguoiLap As System.Windows.Forms.TextBox
    Friend WithEvents ComboBoxMaNSX As System.Windows.Forms.ComboBox
    Friend WithEvents TextBoxMaDH As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBoxGia As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxSoLuong As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents TextBoxMaKH As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaLoaiDH As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaMH As System.Windows.Forms.TextBox
    Friend WithEvents ButtonXoa As System.Windows.Forms.Button
    Friend WithEvents ButtonCapNhat As System.Windows.Forms.Button
End Class
