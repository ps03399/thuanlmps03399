﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Cap_Nhat_Va_Xoa_Khach_Hang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Cap_Nhat_Va_Xoa_Khach_Hang))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ButtonThoat = New System.Windows.Forms.Button()
        Me.ButtonXoa = New System.Windows.Forms.Button()
        Me.ButtonCapNhat = New System.Windows.Forms.Button()
        Me.TextEmail = New System.Windows.Forms.TextBox()
        Me.TextSDT = New System.Windows.Forms.TextBox()
        Me.TextDiaChi = New System.Windows.Forms.TextBox()
        Me.TextTenKH = New System.Windows.Forms.TextBox()
        Me.TextMaKH = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ButtonThoat)
        Me.GroupBox1.Controls.Add(Me.ButtonXoa)
        Me.GroupBox1.Controls.Add(Me.ButtonCapNhat)
        Me.GroupBox1.Controls.Add(Me.TextEmail)
        Me.GroupBox1.Controls.Add(Me.TextSDT)
        Me.GroupBox1.Controls.Add(Me.TextDiaChi)
        Me.GroupBox1.Controls.Add(Me.TextTenKH)
        Me.GroupBox1.Controls.Add(Me.TextMaKH)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(584, 175)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Cập Nhật Và Xóa Khách Hàng"
        '
        'ButtonThoat
        '
        Me.ButtonThoat.Location = New System.Drawing.Point(426, 138)
        Me.ButtonThoat.Name = "ButtonThoat"
        Me.ButtonThoat.Size = New System.Drawing.Size(75, 23)
        Me.ButtonThoat.TabIndex = 17
        Me.ButtonThoat.Text = "Thoát"
        Me.ButtonThoat.UseVisualStyleBackColor = True
        '
        'ButtonXoa
        '
        Me.ButtonXoa.Location = New System.Drawing.Point(270, 138)
        Me.ButtonXoa.Name = "ButtonXoa"
        Me.ButtonXoa.Size = New System.Drawing.Size(75, 23)
        Me.ButtonXoa.TabIndex = 16
        Me.ButtonXoa.Text = "Xoá"
        Me.ButtonXoa.UseVisualStyleBackColor = True
        '
        'ButtonCapNhat
        '
        Me.ButtonCapNhat.Location = New System.Drawing.Point(110, 137)
        Me.ButtonCapNhat.Name = "ButtonCapNhat"
        Me.ButtonCapNhat.Size = New System.Drawing.Size(76, 24)
        Me.ButtonCapNhat.TabIndex = 15
        Me.ButtonCapNhat.Text = "Cập Nhật"
        Me.ButtonCapNhat.UseVisualStyleBackColor = True
        '
        'TextEmail
        '
        Me.TextEmail.Location = New System.Drawing.Point(426, 101)
        Me.TextEmail.Name = "TextEmail"
        Me.TextEmail.Size = New System.Drawing.Size(152, 20)
        Me.TextEmail.TabIndex = 10
        Me.TextEmail.Text = "thuanlmps03399@fpt.edu.vn"
        '
        'TextSDT
        '
        Me.TextSDT.Location = New System.Drawing.Point(110, 101)
        Me.TextSDT.Name = "TextSDT"
        Me.TextSDT.Size = New System.Drawing.Size(181, 20)
        Me.TextSDT.TabIndex = 9
        '
        'TextDiaChi
        '
        Me.TextDiaChi.Location = New System.Drawing.Point(110, 65)
        Me.TextDiaChi.Name = "TextDiaChi"
        Me.TextDiaChi.Size = New System.Drawing.Size(468, 20)
        Me.TextDiaChi.TabIndex = 8
        '
        'TextTenKH
        '
        Me.TextTenKH.Location = New System.Drawing.Point(426, 28)
        Me.TextTenKH.Name = "TextTenKH"
        Me.TextTenKH.Size = New System.Drawing.Size(152, 20)
        Me.TextTenKH.TabIndex = 7
        '
        'TextMaKH
        '
        Me.TextMaKH.Location = New System.Drawing.Point(110, 28)
        Me.TextMaKH.Name = "TextMaKH"
        Me.TextMaKH.Size = New System.Drawing.Size(181, 20)
        Me.TextMaKH.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(373, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Email:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 104)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Số ĐT:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Địa Chỉ"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(331, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Tên Khách Hàng"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Mã Khách Hàng:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DataGridView1)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 193)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(584, 136)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Danh Sách Khách Hàng"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(6, 19)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(572, 109)
        Me.DataGridView1.TabIndex = 0
        '
        'Cap_Nhat_Va_Xoa_Khach_Hang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(613, 336)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Cap_Nhat_Va_Xoa_Khach_Hang"
        Me.Text = "Cập Nhật Và Xóa Khách Hàng"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ButtonThoat As System.Windows.Forms.Button
    Friend WithEvents ButtonXoa As System.Windows.Forms.Button
    Friend WithEvents ButtonCapNhat As System.Windows.Forms.Button
    Friend WithEvents TextEmail As System.Windows.Forms.TextBox
    Friend WithEvents TextSDT As System.Windows.Forms.TextBox
    Friend WithEvents TextDiaChi As System.Windows.Forms.TextBox
    Friend WithEvents TextTenKH As System.Windows.Forms.TextBox
    Friend WithEvents TextMaKH As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
End Class
