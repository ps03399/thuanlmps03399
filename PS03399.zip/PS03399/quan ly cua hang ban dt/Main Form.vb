﻿Public Class Form1

    Private Sub ĐặcĐiểmMặtHàngToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ĐặcĐiểmMặtHàngToolStripMenuItem.Click
        Dac_Diem_Mat_Hang.Show()

    End Sub

    Private Sub ThôngTinNhàSảnXuấtToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ThôngTinNhàSảnXuấtToolStripMenuItem.Click
        Thong_Tin_Nha_San_Xuat.Show()

    End Sub

    Private Sub ThêmMớiToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ThêmMớiToolStripMenuItem.Click
        Them_Moi_Mat_Hang.Show()

    End Sub

    Private Sub CậpNhậtToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CậpNhậtToolStripMenuItem.Click
        Cap_Nhat_va_Xoa_Mat_Hang.Show()

    End Sub

    Private Sub ThêmMớiToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ThêmMớiToolStripMenuItem1.Click
        Them_Khach_Hang.Show()

    End Sub

    Private Sub CậpNhậtToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CậpNhậtToolStripMenuItem1.Click
        Cap_Nhat_Va_Xoa_Khach_Hang.Show()

    End Sub

    Private Sub ThêmMớiToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ThêmMớiToolStripMenuItem2.Click
        Them_Don_Hang.Show()

    End Sub

    Private Sub ThanhToánToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ThanhToánToolStripMenuItem.Click
        Thanh_Toan.Show()

    End Sub
    Private Sub ThoátToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    Private Sub MặtHàngBánChạyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MặtHàngBánChạyToolStripMenuItem.Click
        MatHangBanChay.Show()
    End Sub

    Private Sub TìnhTrạngTồnKhoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TìnhTrạngTồnKhoToolStripMenuItem.Click
        TinhTrangTonKho.Show()
    End Sub

    Private Sub TidmKiếmKháchHàngToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TidmKiếmKháchHàngToolStripMenuItem.Click
        TimKiemKhachHang.Show()

    End Sub

    Private Sub TìmKiếmMặtHàngToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TìmKiếmMặtHàngToolStripMenuItem.Click
        TimKiemMatHang.Show()

    End Sub

    Private Sub FileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileToolStripMenuItem.Click

    End Sub

    Private Sub ĐăngXuấtToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ĐăngXuấtToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ĐơnHàngToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ĐơnHàngToolStripMenuItem.Click

    End Sub
End Class
